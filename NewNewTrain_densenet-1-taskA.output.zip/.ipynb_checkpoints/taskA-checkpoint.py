from model import Multimodel

import pandas as pd
import os
import numpy as np
import codecs
import keras
import random
import cv2
import matplotlib.pyplot as plt

from keras_bert import Tokenizer
#from keras.applications.resnet50 import ResNet50
from keras.preprocessing import image
#from keras.applications.resnet50 import preprocess_input, decode_predictions
from imutils import paths

from keras.optimizers import Adam
from keras.callbacks import EarlyStopping

from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

from keras.utils.vis_utils import plot_model

maxlen = 100 #最开始是200
CLASS_NUM = 3
EPOCHS = 25
INIT_LR = 1e-5 #最好的学习率在5
BATCH_SIZE = 16
ACTIVATION = 'softmax'

model = Multimodel(class_num=CLASS_NUM,activation=ACTIVATION)

train_text_path = r'/openbayes/home/Task_A_train.csv'
trial_text_path = r'/openbayes/home/Task_A_trial.csv'
image_path = r'/openbayes/input/input0/image'

dict_path = '/openbayes/input/input1/BERT/cased_L-12_H-768_A-12/vocab.txt'

def seq_padding(X, padding=0):
    L = [len(x) for x in X]
    ML = max(L)
    return np.array([
        np.concatenate([x, [padding] * (ML - len(x))]) if len(x) < ML else x for x in X
    ])

token_dict = {}

with codecs.open(dict_path, 'r', 'utf8') as reader:
    for line in reader:
        token = line.strip()
        token_dict[token] = len(token_dict)


class OurTokenizer(Tokenizer):
    def _tokenize(self, text):
        R = []
        for c in text:
            if c in self._token_dict:
                R.append(c)
            elif self._is_space(c):
                R.append('[unused1]') # space类用未经训练的[unused1]表示
            else:
                R.append('[UNK]') # 剩余的字符是[UNK]
        return R

tokenizer = OurTokenizer(token_dict)

train_text_data = pd.read_csv(train_text_path)
train_text_data = np.array(train_text_data)
train_text_data = train_text_data.tolist()

trial_text_data = pd.read_csv(trial_text_path)
trial_text_data = np.array(trial_text_data)
trial_text_data = trial_text_data.tolist()

class data_generator:
    def __init__(self, data, batch_size=BATCH_SIZE):
        self.data = data
        self.batch_size = batch_size
        self.steps = len(self.data) // self.batch_size
        if len(self.data) % self.batch_size != 0:
            self.steps += 1
    def __len__(self):
        return self.steps
    def __iter__(self):
        while True:
            idxs = list(range(len(self.data)))
            np.random.shuffle(idxs)
            X1, X2, X3, Y = [], [], [], []
            for i in idxs:
                d = self.data[i]
                text = (str(d[1])+str(d[3]))[:maxlen]
                x1, x2 = tokenizer.encode(first=text)
                imagePath = os.path.join(image_path,d[2])
                img = image.load_img(imagePath, target_size=(224, 224))
                x3 = image.img_to_array(img)
                y = d[0]
                X1.append(x1)
                X2.append(x2)
                X3.append(x3)
                Y.append([y])               
                if len(X1) == self.batch_size or i == idxs[-1]:
                    X1 = seq_padding(X1)
                    X2 = seq_padding(X2)
                    X3 = np.array(X3, dtype="float") / 255.0
                    Y = seq_padding(Y)
#                     Y = np.array(Y)
#                     Y = to_categorical(Y, num_classes=CLASS_NUM)
                    yield [X1, X2, X3], Y
                    [X1, X2, X3, Y] = [], [], [], []
        
train_D = data_generator(train_text_data)
valid_D = data_generator(trial_text_data)

plot_model(model, to_file='model.png', show_shapes = True, show_layer_names = True)

model.compile(
    optimizer=Adam(lr=INIT_LR, decay=INIT_LR / EPOCHS),
    loss='sparse_categorical_crossentropy',
    metrics=['sparse_categorical_accuracy'],
             )

model.summary()


class_weight = {0: 2,
                1: 1,
                2: 4}
es = EarlyStopping(monitor='val_loss', patience=5)
model.fit_generator(
    train_D.__iter__(),
    steps_per_epoch=len(train_D),
    epochs=EPOCHS,
    validation_data=valid_D.__iter__(),
    validation_steps=len(valid_D),
    class_weight = class_weight,
    verbose=2,
    #callbacks=[es]
)


class data_generator_test:
    def __init__(self, data, batch_size=BATCH_SIZE):
        self.data = data
        self.batch_size = batch_size
        self.steps = len(self.data) // self.batch_size
        if len(self.data) % self.batch_size != 0:
            self.steps += 1
    def __len__(self):
        return self.steps
    def __iter__(self):
        while True:
            idxs = list(range(len(self.data)))
            X1, X2, X3 = [], [], []
            for i in idxs:
                d = self.data[i]
                text = (str(d[1])+str(d[2]))[:maxlen]
                x1, x2 = tokenizer.encode(first=text)
                imagePath = os.path.join(image_path,d[2])
                img = image.load_img(imagePath, target_size=(224, 224))
                x3 = image.img_to_array(img)
                X1.append(x1)
                X2.append(x2)
                X3.append(x3)           
                if len(X1) == self.batch_size or i == idxs[-1]:
                    X1 = seq_padding(X1)
                    X2 = seq_padding(X2)
                    X3 = np.array(X3, dtype="float") / 255.0
                    yield [X1, X2, X3]
                    [X1, X2, X3] = [], [], []
                    

test_text_path = r'processed_test.csv'
test_text_data = pd.read_csv(test_text_path)
test_text_data = np.array(test_text_data)
test_text_data = test_text_data.tolist()
test_x = data_generator_test(test_text_data)
predicts = model.predict(test_x.__iter__(),steps = len(test_x))
pd.DataFrame(predicts.argmax(axis=-1)).to_csv("predict_task_A_v2.csv",index=False)