import keras
from keras.layers import *
from keras.models import Model
from keras.applications.densenet import DenseNet121
from keras_bert import load_trained_model_from_checkpoint
from keras import regularizers

config_path = '/openbayes/input/input1/BERT/cased_L-12_H-768_A-12/bert_config.json'
checkpoint_path = '/openbayes/input/input1/BERT/cased_L-12_H-768_A-12/bert_model.ckpt'


def Multimodel(class_num,activation):
    bert_x1_in = Input(shape=(None,))
    bert_x2_in = Input(shape=(None,))
    img_in = Input(shape=(224,224,3))
    bert_model = load_trained_model_from_checkpoint(config_path, checkpoint_path, seq_len=None)
    for l in bert_model.layers:
        l.trainable = True
    dense=DenseNet121(include_top=False,input_shape=(224,224,3))
    
    bert=bert_model([bert_x1_in, bert_x2_in])
    top1_model=Lambda(lambda bert: bert[:, 0])(bert)
    
    dense=dense(img_in)
    top2_model=GlobalMaxPooling2D(data_format='channels_last')(dense)
    
    t = keras.layers.Concatenate(axis=1)([top1_model,top2_model])
    
    top_model=Dense(units=512,activation="relu")(t)
    top_model=Dropout(rate=0.7)(top_model)
    p=Dense(units=class_num,activation=activation,kernel_regularizer=regularizers.l2(0.01))(top_model)
    
    model = Model([bert_x1_in, bert_x2_in, img_in], p)
    
    return model